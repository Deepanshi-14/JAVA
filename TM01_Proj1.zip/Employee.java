public class Employee {

	public static void main(String[] args) {
		String employee_id = args[0];
		String[][] Employee = {
				{"Emp No.","Emp Name","Join Date","Designation Code","Basic","HRA","IT"},
				{"1001","1002","1003","1004","1005","1006","1007"},
				{"Ashish","Sushma","Rahul","Chahat","Ranjan","Suman","Tanmay"},
				{"01/04/2009","23/08/2012","12/11/2008","29/01/2013","16/07/2005","01/01/2000","12/06/2006"},
				{"e","c","k","r","m","e","c"},
				{"R&D","PM","Acct","Front Desk","Engg","Manufacturing","PM"},
				{"20000","30000","10000","12000","50000","23000","29000"},
				{"8000","12000","8000","6000","20000","9000","12000"},
				{"3000","9000","1000","2000","20000","4400","10000"}
		};
		String[][] DA = {
				{"e","c","k","r","m"},
				{"Engineer","Consultant","Clerk","Receptionist","Manager"},
				{"20000","32000","12000","15000","40000"}
		};
		
		String Designation ="", DearnessAllowance="";
		int currentIndex = -1;
		for(int i=0;i<Employee[1].length;i++)
		{
			if(Employee[1][i].equals(employee_id))
			{
				currentIndex = i;
			}
		}
		if(currentIndex==-1)
		{
			System.out.println("There is no employee with empid : " + employee_id );
		}
		else
		{
			int codeIndex = 0;
			String code = Employee[4][currentIndex];
			for(int j=0;j<DA[0].length;j++)
			{
				if(DA[0][j].equals(code))
				{
					codeIndex = j;
				}
			}
			switch(code)
		    {
		    case "e":
		    	Designation = DA[1][codeIndex];
     		    DearnessAllowance= DA[2][codeIndex];
		    break;
		    case "c":
		    	Designation = DA[1][codeIndex];
     		    DearnessAllowance= DA[2][codeIndex];
		    break;
		    case "k":
		    	Designation = DA[1][codeIndex];
     		    DearnessAllowance= DA[2][codeIndex];
		    break;
		    case "r":
		    	Designation = DA[1][codeIndex];
     		    DearnessAllowance= DA[2][codeIndex];
		    break;
		    case "m":
		    	Designation = DA[1][codeIndex];
     		    DearnessAllowance= DA[2][codeIndex];
		    break;
		    }
			
			int Salary=Integer.parseInt(Employee[6][currentIndex]) + Integer.parseInt(Employee[7][currentIndex]) + Integer.parseInt(DearnessAllowance) - Integer.parseInt(Employee[8][currentIndex]);
		    System.out.println("EmpNo" + "\t "+"EmpName"+"\t"+"Department"+"\t"+"Designation"+"\t"+"Salary");
		    System.out.printf("%s\t %s\t\t %s\t\t %s\t %d",employee_id,Employee[2][currentIndex],Employee[5][currentIndex],Designation,Salary);
		}
	    
	    

	}

}
