import java.util.Scanner;
public class lb3 {

 public static void main(String[] args) {
  Scanner sc = new Scanner(System.in);
  int n1 = sc.nextInt();
  int n2 = sc.nextInt();
  int n3 = n1 + n2;
  System.out.println("The sum of " + n1 + " and " + n2 + " is " + n3);
 }
}  