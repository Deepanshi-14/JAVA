import java.util.Scanner;
public class fc15 {
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int sum=0;
        for(sum=0; n>0; n=n/10)
        {
            sum = sum + (n%10);
        }
        System.out.println(sum);
    }
}
