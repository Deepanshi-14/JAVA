package arrays;
import java.util.ArrayList;
import java.util.Scanner;

public class a10 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size of array:");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter array elements:");
		for(int i=0;i<size;i++)
		{
			a[i] = sc.nextInt();
		}
		ArrayList<Integer> evenOdd = new ArrayList<>();
		for(int num:a)
		{
			if(num%2 == 0)
			{
				evenOdd.add(num);
			}
		}
		for(int num:a)
		{
			if(num%2!=0)
			{
				evenOdd.add(num);
			}
		}
		for(int i=0;i<evenOdd.size();i++)
		{
		System.out.print(evenOdd.get(i) + " ");
		}
	}

}
