package arrays;
import java.util.Scanner;
public class a12 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] a = new int[3];
		int[] b = new int[3];
		System.out.println("Enter 3 elements of first array :");
		for(int i=0;i<3;i++)
		{
			a[i] = sc.nextInt();
		}
		System.out.println("Enter 3 elements of second array :");
		for(int i=0;i<3;i++)
		{
			b[i] = sc.nextInt();
		}
		int[] c = new int[2];
		System.out.println("[" + a[1] + " " + b[1] + "]");
		
	}

}
