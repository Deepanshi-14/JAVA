package arrays;
import java.util.Scanner;
public class a5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size of array:");
		int size = sc.nextInt();
		int[] array = new int[size] ;
		System.out.println("Enter array elements:");
		for(int i=0;i<size-1;i++)
		{
			array[i] = sc.nextInt();
		}
        for(int i=0;i<size-1;i++)
        {
        	for(int j=0;j<size-1;j++)
        	{
        		if(array[j+1]<array[j]) 
        		{
        			int temp = array[j+1];
        			array[j+1] = array[j];
        			array[j] = temp;
        		}
        	}
        }
        System.out.println("Largest 2 numbers are : " + array[size-1] + " and " + array[size-2] );
        System.out.println("Smallest 2 numbers are : " + array[0] + " and " + array[1] );
	}

}
