package arrays;

public class a1{
    public static void main(String[] args){
        int[] array = {7,9,16,25,31,33};
        int total=0;
        
        for(int i=0;i<array.length;i++)
        {
            total += array[i];
        }
        float average = (float)total/(array.length);
        System.out.println("Sum of array is " + total);
        System.out.printf("Average of array is %.3f" , average);
    }
}