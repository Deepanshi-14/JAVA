package arrays;

public class a2 {
    public static void main(String[] args){
        int[] array={3,6,10,12,13,15,18};
        int max=0, min=array[0];
        for(int i=0;i<array.length;i++)
        {
            if(array[i]>max)
            {
                max = array[i];
            }
            if(array[i]<min)
            {
                min=array[i];
            }
        }
        System.out.println("Maximum value = " + max + " and Minimum value = " + min);
    }
}
