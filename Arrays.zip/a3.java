package arrays;

import java.util.Scanner;
public class a3 {
    public static void main(String[] args){
        int[] array = {3,6,10,12,13,15,18,20};
        int flag=0,i;
        System.out.println("Enter the element to be searched :");
        Scanner sc = new Scanner(System.in);
        int search = sc.nextInt();
        for(i=0;i<array.length;i++)
        {
            if(array[i]==search)
            {
             flag = 1;
             break;
            }
        }
        if(flag == 1)
         System.out.println(i);
        else
         System.out.println("-1");

        
         
    }
}
