package arrays;
import java.util.ArrayList;
import java.util.Scanner;
public class a9 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size of array:");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter array elements:");
		for(int i=0;i<size;i++)
		{
			a[i] = sc.nextInt();
		}
		ArrayList<Integer> withoutTen = new ArrayList<>();
        for (int number : a) 
        {
            if (number != 10)
                withoutTen.add(number);
        }
        while (a.length > withoutTen.size()) {
            withoutTen.add(0);
        }
        for(int i=0;i<withoutTen.size();i++)
        {
        	System.out.print(withoutTen.get(i) + " ");
        }
	}

}
