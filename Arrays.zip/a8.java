package arrays;

import java.util.Scanner;

public class a8 
{
	public static void main(String[] args) 
	{  
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter size of array:");
	int size = sc.nextInt();
	int[] array = new int[size] ;
	int sum1=0, sum2=0;
	int x=0, y=0;
	System.out.println("Enter array elements:");
	for(int i=0;i<size;i++)
	{
		array[i] = sc.nextInt();
	}
	for(int i=0;i<array.length;i++)
	{
		if(array[i]==6)
			x = i;
		if(array[i]==7)
			y = i;
	}
	if(x<y)
	{
		for(int i=0;i<x;i++)
		{
			sum1 += array[i];
		}
		for(int i=y+1;i<array.length;i++)
		{
			sum2 += array[i];
		}
		System.out.print(sum1 + sum2);		
	}
	else
	{
		for(int i=0;i<array.length;i++)
		{
			sum1 += array[i];
		}
		System.out.print(sum1);
	}
		
	}
}
